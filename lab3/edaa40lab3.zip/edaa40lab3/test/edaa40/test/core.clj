(ns edaa40.test.core
  (:use [edaa40.core])
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false "No tests have been written."))
