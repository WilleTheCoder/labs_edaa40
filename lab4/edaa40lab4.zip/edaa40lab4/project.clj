(defproject edaa40 "1.0.0-SNAPSHOT"
  :description "FIXME: write description"
  :main edaa40.user
  :dependencies [[org.clojure/clojure "1.8.0"]])
